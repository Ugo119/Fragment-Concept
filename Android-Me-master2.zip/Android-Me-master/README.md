# Android Me
This app was built with the help of an online course on Udacity, [Advanced Android App Development](https://in.udacity.com/course/advanced-android-app-development--ud855) as part of the Android Developer Nanodegree Program.</br></br>
User can select from a list of head, body and leg images to customize their own Android character. Further tapping on the head, body or legs of the character increments through options in the list. This project is a good exercise on building and using fragments within activities.</br></br>
<img src="https://github.com/Shrreya/Android-Me/blob/master/screenshots/1.png" width="288" height="512" />
<img src="https://github.com/Shrreya/Android-Me/blob/master/screenshots/2.png" width="288" height="512" />
<img src="https://github.com/Shrreya/Android-Me/blob/master/screenshots/3.png" width="288" height="512" />
